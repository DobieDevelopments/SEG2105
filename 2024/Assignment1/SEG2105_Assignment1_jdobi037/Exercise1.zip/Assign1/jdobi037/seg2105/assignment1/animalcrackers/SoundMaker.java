package jdobi037.seg2105.assignment1.animalcrackers;

/**
 * the interface for the soundmaker for inheritors to make sounds with
 * 
 * @author John Dobie - jdobi037@uottawa.ca - 300443432
 */
interface SoundMaker{
	//Outputs a sound
    public void MakeSound();
}